
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.randomthings.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fluids.FluidType;

import net.mcreator.randomthings.fluid.types.RadietatedWaterFluidType;
import net.mcreator.randomthings.RandomThingsMod;

public class RandomThingsModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(ForgeRegistries.Keys.FLUID_TYPES, RandomThingsMod.MODID);
	public static final RegistryObject<FluidType> RADIETATED_WATER_TYPE = REGISTRY.register("radietated_water", () -> new RadietatedWaterFluidType());
}
