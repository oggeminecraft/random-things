
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.randomthings.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.randomthings.item.RadietatedWaterItem;
import net.mcreator.randomthings.item.NetheriteAppleItem;
import net.mcreator.randomthings.item.FragetackenItem;
import net.mcreator.randomthings.item.BombwastelandItem;
import net.mcreator.randomthings.item.BedrockSwordItem;
import net.mcreator.randomthings.RandomThingsMod;

public class RandomThingsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, RandomThingsMod.MODID);
	public static final RegistryObject<Item> BEDROCK_SWORD = REGISTRY.register("bedrock_sword", () -> new BedrockSwordItem());
	public static final RegistryObject<Item> NETHERITE_APPLE = REGISTRY.register("netherite_apple", () -> new NetheriteAppleItem());
	public static final RegistryObject<Item> RADIATED_DIRT = block(RandomThingsModBlocks.RADIATED_DIRT);
	public static final RegistryObject<Item> BOMBWASTELAND = REGISTRY.register("bombwasteland", () -> new BombwastelandItem());
	public static final RegistryObject<Item> DEAD_TREE_LOG = block(RandomThingsModBlocks.DEAD_TREE_LOG);
	public static final RegistryObject<Item> DEAD_TREE_WOOD = block(RandomThingsModBlocks.DEAD_TREE_WOOD);
	public static final RegistryObject<Item> DEAD_TREE_PLANKS = block(RandomThingsModBlocks.DEAD_TREE_PLANKS);
	public static final RegistryObject<Item> DEAD_TREE_LEAVES = block(RandomThingsModBlocks.DEAD_TREE_LEAVES);
	public static final RegistryObject<Item> DEAD_TREE_STAIRS = block(RandomThingsModBlocks.DEAD_TREE_STAIRS);
	public static final RegistryObject<Item> DEAD_TREE_SLAB = block(RandomThingsModBlocks.DEAD_TREE_SLAB);
	public static final RegistryObject<Item> DEAD_TREE_FENCE = block(RandomThingsModBlocks.DEAD_TREE_FENCE);
	public static final RegistryObject<Item> DEAD_TREE_FENCE_GATE = block(RandomThingsModBlocks.DEAD_TREE_FENCE_GATE);
	public static final RegistryObject<Item> DEAD_TREE_PRESSURE_PLATE = block(RandomThingsModBlocks.DEAD_TREE_PRESSURE_PLATE);
	public static final RegistryObject<Item> PLACEHOLDER_SPAWN_EGG = REGISTRY.register("placeholder_spawn_egg", () -> new ForgeSpawnEggItem(RandomThingsModEntities.PLACEHOLDER, -10040320, -16751104, new Item.Properties()));
	public static final RegistryObject<Item> RADIETATED_WATER_BUCKET = REGISTRY.register("radietated_water_bucket", () -> new RadietatedWaterItem());
	public static final RegistryObject<Item> DEAD_TREE_BUTTON = block(RandomThingsModBlocks.DEAD_TREE_BUTTON);
	public static final RegistryObject<Item> FRAGETACKEN = REGISTRY.register("fragetacken", () -> new FragetackenItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
