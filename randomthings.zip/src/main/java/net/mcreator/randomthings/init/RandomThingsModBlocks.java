
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.randomthings.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.randomthings.block.RadietatedWaterBlock;
import net.mcreator.randomthings.block.RadiatedDirtBlock;
import net.mcreator.randomthings.block.DeadTreeWoodBlock;
import net.mcreator.randomthings.block.DeadTreeStairsBlock;
import net.mcreator.randomthings.block.DeadTreeSlabBlock;
import net.mcreator.randomthings.block.DeadTreePressurePlateBlock;
import net.mcreator.randomthings.block.DeadTreePlanksBlock;
import net.mcreator.randomthings.block.DeadTreeLogBlock;
import net.mcreator.randomthings.block.DeadTreeLeavesBlock;
import net.mcreator.randomthings.block.DeadTreeFenceGateBlock;
import net.mcreator.randomthings.block.DeadTreeFenceBlock;
import net.mcreator.randomthings.block.DeadTreeButtonBlock;
import net.mcreator.randomthings.block.BombwastelandPortalBlock;
import net.mcreator.randomthings.RandomThingsMod;

public class RandomThingsModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, RandomThingsMod.MODID);
	public static final RegistryObject<Block> RADIATED_DIRT = REGISTRY.register("radiated_dirt", () -> new RadiatedDirtBlock());
	public static final RegistryObject<Block> BOMBWASTELAND_PORTAL = REGISTRY.register("bombwasteland_portal", () -> new BombwastelandPortalBlock());
	public static final RegistryObject<Block> DEAD_TREE_LOG = REGISTRY.register("dead_tree_log", () -> new DeadTreeLogBlock());
	public static final RegistryObject<Block> DEAD_TREE_WOOD = REGISTRY.register("dead_tree_wood", () -> new DeadTreeWoodBlock());
	public static final RegistryObject<Block> DEAD_TREE_PLANKS = REGISTRY.register("dead_tree_planks", () -> new DeadTreePlanksBlock());
	public static final RegistryObject<Block> DEAD_TREE_LEAVES = REGISTRY.register("dead_tree_leaves", () -> new DeadTreeLeavesBlock());
	public static final RegistryObject<Block> DEAD_TREE_STAIRS = REGISTRY.register("dead_tree_stairs", () -> new DeadTreeStairsBlock());
	public static final RegistryObject<Block> DEAD_TREE_SLAB = REGISTRY.register("dead_tree_slab", () -> new DeadTreeSlabBlock());
	public static final RegistryObject<Block> DEAD_TREE_FENCE = REGISTRY.register("dead_tree_fence", () -> new DeadTreeFenceBlock());
	public static final RegistryObject<Block> DEAD_TREE_FENCE_GATE = REGISTRY.register("dead_tree_fence_gate", () -> new DeadTreeFenceGateBlock());
	public static final RegistryObject<Block> DEAD_TREE_PRESSURE_PLATE = REGISTRY.register("dead_tree_pressure_plate", () -> new DeadTreePressurePlateBlock());
	public static final RegistryObject<Block> RADIETATED_WATER = REGISTRY.register("radietated_water", () -> new RadietatedWaterBlock());
	public static final RegistryObject<Block> DEAD_TREE_BUTTON = REGISTRY.register("dead_tree_button", () -> new DeadTreeButtonBlock());
}
