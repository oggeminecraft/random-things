
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.randomthings.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.randomthings.RandomThingsMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class RandomThingsModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, RandomThingsMod.MODID);
	public static final RegistryObject<CreativeModeTab> RANDOMTHINGS = REGISTRY.register("randomthings",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.random_things.randomthings")).icon(() -> new ItemStack(RandomThingsModItems.FRAGETACKEN.get())).displayItems((parameters, tabData) -> {
				tabData.accept(RandomThingsModItems.BEDROCK_SWORD.get());
				tabData.accept(RandomThingsModItems.NETHERITE_APPLE.get());
				tabData.accept(RandomThingsModBlocks.RADIATED_DIRT.get().asItem());
				tabData.accept(RandomThingsModItems.BOMBWASTELAND.get());
				tabData.accept(RandomThingsModBlocks.DEAD_TREE_LOG.get().asItem());
				tabData.accept(RandomThingsModBlocks.DEAD_TREE_WOOD.get().asItem());
				tabData.accept(RandomThingsModBlocks.DEAD_TREE_PLANKS.get().asItem());
				tabData.accept(RandomThingsModBlocks.DEAD_TREE_LEAVES.get().asItem());
				tabData.accept(RandomThingsModBlocks.DEAD_TREE_STAIRS.get().asItem());
				tabData.accept(RandomThingsModBlocks.DEAD_TREE_SLAB.get().asItem());
				tabData.accept(RandomThingsModBlocks.DEAD_TREE_FENCE.get().asItem());
				tabData.accept(RandomThingsModBlocks.DEAD_TREE_FENCE_GATE.get().asItem());
				tabData.accept(RandomThingsModBlocks.DEAD_TREE_PRESSURE_PLATE.get().asItem());
				tabData.accept(RandomThingsModItems.PLACEHOLDER_SPAWN_EGG.get());
				tabData.accept(RandomThingsModItems.RADIETATED_WATER_BUCKET.get());
			})

					.build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {

		if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(RandomThingsModBlocks.DEAD_TREE_BUTTON.get().asItem());
		}
	}
}
