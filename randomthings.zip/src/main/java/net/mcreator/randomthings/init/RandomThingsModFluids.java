
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.randomthings.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.mcreator.randomthings.fluid.RadietatedWaterFluid;
import net.mcreator.randomthings.RandomThingsMod;

public class RandomThingsModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(ForgeRegistries.FLUIDS, RandomThingsMod.MODID);
	public static final RegistryObject<FlowingFluid> RADIETATED_WATER = REGISTRY.register("radietated_water", () -> new RadietatedWaterFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_RADIETATED_WATER = REGISTRY.register("flowing_radietated_water", () -> new RadietatedWaterFluid.Flowing());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(RADIETATED_WATER.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_RADIETATED_WATER.get(), RenderType.translucent());
		}
	}
}
