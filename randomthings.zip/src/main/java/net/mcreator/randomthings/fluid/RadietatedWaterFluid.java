
package net.mcreator.randomthings.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;

import net.mcreator.randomthings.init.RandomThingsModItems;
import net.mcreator.randomthings.init.RandomThingsModFluids;
import net.mcreator.randomthings.init.RandomThingsModFluidTypes;
import net.mcreator.randomthings.init.RandomThingsModBlocks;

public abstract class RadietatedWaterFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> RandomThingsModFluidTypes.RADIETATED_WATER_TYPE.get(), () -> RandomThingsModFluids.RADIETATED_WATER.get(),
			() -> RandomThingsModFluids.FLOWING_RADIETATED_WATER.get()).explosionResistance(100f).bucket(() -> RandomThingsModItems.RADIETATED_WATER_BUCKET.get()).block(() -> (LiquidBlock) RandomThingsModBlocks.RADIETATED_WATER.get());

	private RadietatedWaterFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return ParticleTypes.DRIPPING_WATER;
	}

	public static class Source extends RadietatedWaterFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends RadietatedWaterFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
